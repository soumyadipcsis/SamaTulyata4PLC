# equivchecker
This project analyses two programs to verify their behavioural equivalence. the executable folder contains readily deployable (Ubuntu version) tools. 
Executable: Contains two versions of the tool, version1- commandline and version2- Eclipse Plugin
EquivalenceChecker: This folder contains the source code of the plugin. 
